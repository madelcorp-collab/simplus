import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const db = new Database("inventory.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    is_paid INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category_id INTEGER,
    quantity INTEGER DEFAULT 0,
    min_quantity INTEGER DEFAULT 5,
    price REAL,
    cost REAL,
    FOREIGN KEY(category_id) REFERENCES categories(id)
  );

  CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    quantity INTEGER,
    total_price REAL,
    total_cost REAL,
    sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(product_id) REFERENCES products(id)
  );
`);

// Seed Admin User
const adminExists = db.prepare("SELECT * FROM users WHERE username = ?").get("ADMIN");
if (!adminExists) {
  db.prepare("INSERT INTO users (username, password, is_paid) VALUES (?, ?, ?)").run("ADMIN", "123teste", 1);
}

// Seed Categories if empty
const catCount = db.prepare("SELECT COUNT(*) as count FROM categories").get() as { count: number };
if (catCount.count === 0) {
  db.prepare("INSERT INTO categories (name) VALUES (?)").run("Suplementos");
  db.prepare("INSERT INTO categories (name) VALUES (?)").run("Geladeira");
  db.prepare("INSERT INTO categories (name) VALUES (?)").run("Acessórios");
}

// Seed Sample Products
const productCount = db.prepare("SELECT COUNT(*) as count FROM products").get() as { count: number };
if (productCount.count === 0) {
  db.prepare("INSERT INTO products (name, category_id, quantity, min_quantity, price, cost) VALUES (?, ?, ?, ?, ?, ?)").run("Whey Protein Iso - Dux (900g)", 1, 15, 5, 219.00, 150.00);
  db.prepare("INSERT INTO products (name, category_id, quantity, min_quantity, price, cost) VALUES (?, ?, ?, ?, ?, ?)").run("Energético Monster 473ml", 2, 3, 10, 12.00, 7.50);
  db.prepare("INSERT INTO products (name, category_id, quantity, min_quantity, price, cost) VALUES (?, ?, ?, ?, ?, ?)").run("Creatina Monohidratada 300g", 1, 25, 8, 89.90, 45.00);
  db.prepare("INSERT INTO products (name, category_id, quantity, min_quantity, price, cost) VALUES (?, ?, ?, ?, ?, ?)").run("Coqueteleira Pro 600ml", 3, 12, 5, 35.00, 15.00);
}

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // --- API ROUTES ---

  // Auth
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE username = ? AND password = ?").get(username, password) as any;
    if (user) {
      res.json({ success: true, user: { id: user.id, username: user.username, is_paid: user.is_paid } });
    } else {
      res.status(401).json({ success: false, message: "Credenciais inválidas" });
    }
  });

  app.post("/api/register", (req, res) => {
    const { username, password } = req.body;
    try {
      const info = db.prepare("INSERT INTO users (username, password, is_paid) VALUES (?, ?, ?)").run(username, password, 0);
      res.json({ success: true, userId: info.lastInsertRowid });
    } catch (e) {
      res.status(400).json({ success: false, message: "Usuário já existe" });
    }
  });

  app.post("/api/pay", (req, res) => {
    const { userId } = req.body;
    db.prepare("UPDATE users SET is_paid = 1 WHERE id = ?").run(userId);
    res.json({ success: true });
  });

  // Products
  app.get("/api/products", (req, res) => {
    const products = db.prepare(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id
    `).all();
    res.json(products);
  });

  app.post("/api/products", (req, res) => {
    const { name, category_id, quantity, min_quantity, price, cost } = req.body;
    const info = db.prepare("INSERT INTO products (name, category_id, quantity, min_quantity, price, cost) VALUES (?, ?, ?, ?, ?, ?)").run(name, category_id, quantity, min_quantity, price, cost);
    res.json({ success: true, id: info.lastInsertRowid });
  });

  app.put("/api/products/:id", (req, res) => {
    const { id } = req.params;
    const { name, category_id, quantity, min_quantity, price, cost } = req.body;
    db.prepare("UPDATE products SET name = ?, category_id = ?, quantity = ?, min_quantity = ?, price = ?, cost = ? WHERE id = ?").run(name, category_id, quantity, min_quantity, price, cost, id);
    res.json({ success: true });
  });

  app.delete("/api/products/:id", (req, res) => {
    const { id } = req.params;
    db.prepare("DELETE FROM products WHERE id = ?").run(id);
    res.json({ success: true });
  });

  // Categories
  app.get("/api/categories", (req, res) => {
    const categories = db.prepare("SELECT * FROM categories").all();
    res.json(categories);
  });

  // Sales
  app.post("/api/sales", (req, res) => {
    const { product_id, quantity } = req.body;
    const product = db.prepare("SELECT * FROM products WHERE id = ?").get(product_id) as any;
    
    if (!product || product.quantity < quantity) {
      return res.status(400).json({ success: false, message: "Estoque insuficiente" });
    }

    const total_price = product.price * quantity;
    const total_cost = product.cost * quantity;

    db.prepare("INSERT INTO sales (product_id, quantity, total_price, total_cost) VALUES (?, ?, ?, ?)").run(product_id, quantity, total_price, total_cost);
    db.prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?").run(quantity, product_id);

    res.json({ success: true });
  });

  app.get("/api/dashboard", (req, res) => {
    const { filter, start, end } = req.query;
    let dateFilter = "";
    
    if (filter === "today") {
      dateFilter = "WHERE date(sale_date) = date('now', 'localtime')";
    } else if (filter === "yesterday") {
      dateFilter = "WHERE date(sale_date) = date('now', '-1 day', 'localtime')";
    } else if (filter === "7days") {
      dateFilter = "WHERE date(sale_date) >= date('now', '-7 days', 'localtime')";
    } else if (filter === "30days") {
      dateFilter = "WHERE date(sale_date) >= date('now', '-30 days', 'localtime')";
    } else if (filter === "custom" && start && end) {
      dateFilter = `WHERE date(sale_date) BETWEEN date('${start}') AND date('${end}')`;
    }

    const stats = db.prepare(`
      SELECT 
        SUM(total_price) as total_sales,
        SUM(total_price - total_cost) as total_profit,
        COUNT(*) as sales_count
      FROM sales
      ${dateFilter}
    `).get() as any;

    const stockStats = db.prepare(`
      SELECT 
        SUM(quantity) as total_items,
        COUNT(*) FILTER (WHERE quantity <= min_quantity) as low_stock_count
      FROM products
    `).get() as any;

    res.json({
      sales: stats.total_sales || 0,
      profit: stats.total_profit || 0,
      salesCount: stats.sales_count || 0,
      totalItems: stockStats.total_items || 0,
      lowStockCount: stockStats.low_stock_count || 0
    });
  });

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
